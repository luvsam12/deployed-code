const forgotPassword = (link) => {
    // console.log(link);

    return `
      <!DOCTYPE html>
     <html style="margin: 0; padding: 0;">
     
         <head>
             <title>Hello</title>
         </head>
     
             <body style="margin: 0; padding: 0;">
             
                <br />
                <br />

                <div> We have received a request for password change , click this link to change password ${link}  </div>
                <br />
                <br />
             </body>
     
       </html>
      `;
  };
  
  module.exports = { forgotPassword };
  