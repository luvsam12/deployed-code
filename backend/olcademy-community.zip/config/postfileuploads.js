const multer = require("multer");
const path = require("path");
const webp = require("webp-converter");
const fs = require("fs");
// this will grant 755 permission to webp executables
webp.grant_permission();

const storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, "public/uploads");
  },
  filename: (req, file, callBack) => {
    callBack(null, Date.now() + path.extname(file.originalname));
  },
});

//route for handling image uploads
const uploadImages = (req, res) => {
  var mediaArrayWithLink = [];
  var mediaArray = [];
  var tagArray = [];
  for (var i = 0; i < req.files.length; i++) {
    var fileName = req.files[i].path.replace(/^.*[\\\/]/, "").split(".")[0];
    var path = "public/uploads/" + fileName + ".webp";
    var tag =
      "<div><img src='" + path + "' ></div>";
    mediaArray.push(path);
    tagArray.push(tag);
    webp
      .cwebp(req.files[i].path, "public/uploads/" + fileName + ".webp", "-q 80")
      .then((response) => {});
  }
  mediaArrayWithLink.push(mediaArray);
  mediaArrayWithLink.push(tagArray);
  res.json(mediaArrayWithLink);
};

const uploadVideos = (req, res) => {
  console.log(req.files);
  var mediaArrayWithLink = [];
  var mediaArray = [];
  var tagArray = [];
  for (var i = 0; i < req.files.length; i++) {
    var path = "public/uploads/" + req.files[i].filename;
    var tag =
      "</div><iframe class='ql-video' frameborder='0' allowfullscreen='true' src='" +
      path.substring(6) +
      "'></iframe>";
    mediaArray.push(path);
    tagArray.push(tag);
  }
  mediaArrayWithLink.push(mediaArray);
  mediaArrayWithLink.push(tagArray);
  res.json(mediaArrayWithLink);
};

const uploadDocuments = (req, res) => {
  var mediaArrayWithLink = [];
  var mediaArray = [];
  var tagArray = [];
  for (var i = 0; i < req.files.length; i++) {
    var path = "public/uploads/" + req.files[i].filename;
    var tag =
      "<div><a href='" +
      path.substring(6) +
      "'>" +
      req.files[i].filename +
      "</a></div>";
    mediaArray.push(path);
    tagArray.push(tag);
  }
  mediaArrayWithLink.push(mediaArray);
  mediaArrayWithLink.push(tagArray);
  res.json(mediaArrayWithLink);
};

const upload = multer({ storage: storage });

module.exports = {
  storage,
  upload,
  uploadImages,
  uploadVideos,
  uploadDocuments,
};
