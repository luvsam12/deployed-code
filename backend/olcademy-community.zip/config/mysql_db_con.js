// var mysql = require("mysql");
// var connection = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   password: "",
//   database: "olcademy1",
// });

// connection.connect((err) => {
//   if (err) console.log("Not Connected to MYSQL DB!");
//   else console.log("Connected to MYSQL DB!");
// });

// module.exports = connection;
