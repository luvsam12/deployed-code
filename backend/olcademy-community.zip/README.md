# Olcademy--community backend

# To Run API

```
git clone -b backend https://gitlab.com/olcademy/olcademy-community.git
npm install
npm run server
localhost:7000
```

endpoints

```
localhost:7000/api/categories                        --GET Categories
localhost:7000/api/testcategories                    --GET Test Categories

localhost:7000/header_icons/header_sprite.svg        --GET header icons sprite image

localhost:7000/api/user/:cookie_id                   --GET JWT token and User Data  **to be made post request
localhost:7000/api/userProfileImg                    --GET User profile Image
localhost:7000/api/user                              --GET Show Popup boolean value

localhost:7000/interest_images/interest_sprite.webp  --GET Interest sprite Images

localhost:7000/api/userInterest                      --GET & POST user interests

localhost:7000/api/blog                              --GET & POST blog
localhost:7000/api/blog/:blog_id                     --PUT & DELETE blog
```
