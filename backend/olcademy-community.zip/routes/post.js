const express = require("express");
const router = express.Router();
const {
  storage,
  upload,
  uploadImages,
  uploadVideos,
  uploadDocuments,
} = require("../config/postfileuploads");

//middleware function
const auth = require("../middleware/auth");

//Controller functions
const {
  getBlogs,
  getForums,
  getSinglePost,
  createPost,
  deletePost,
  updatePost,
  getPostByCategory,
} = require("../controllers/post.js");

//Route to get blogs
router.get("/blog", getBlogs);

//Route to get forums
router.get("/forums", getForums);

//Route for uploading files
router.post("/uploadImages", auth, upload.array("media"), uploadImages);

//Route for uploading Videos
router.post("/uploadVideos", auth, upload.array("media"), uploadVideos);

//Route for uploading Documents
router.post("/uploadDocuments", auth, upload.array("media"), uploadDocuments);

//Route to get blogs
router.get("/post/:post_id", getSinglePost);

//Route to get blogs by category
router.get("/:category_name/posts", getPostByCategory);

//Route to post a blog
router.post("/post", auth, upload.array("media"), createPost);

//Route to delete a blog
router.delete("/post/:post_id", auth, deletePost);

//Route to update a blog
router.put("/post/:post_id", auth, upload.array("media"), updatePost);

module.exports = router;
