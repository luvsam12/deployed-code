const Posts = require("../models/post");
const Users = require("../models/user");
const Comments = require("../models/comment");
const ReplyComments = require("../models/commentreply");
const Notifications = require("../models/notification");
const Reports = require("../models/report");
const ObjectId = require("mongodb").ObjectID;
const fs = require("fs");

exports.getBlogs = (req, res) => {
  Posts.find({ show: 1, post_type: "Blogs" })
    .sort({ published_on: -1 })
    .populate("category")
    .then((post) => {
      res.json(post);
    })
    .catch((err) => {
      console.log(err);
      res.status(404).send("No Blog Found");
    });
};

exports.getForums = (req, res) => {
  Posts.find({ show: 1, post_type: "Forums" })
    .sort({ published_on: -1 })
    .populate("category")
    .then((post) => {
      res.json(post);
    })
    .catch((err) => {
      res.status(404).send("No Forums Found");
    });
};

exports.getSinglePost = (req, res) => {
  Posts.findOne({ _id: ObjectId(req.params.post_id) })
    .populate("category")
    .then((post) => {
      res.json(post);
    })
    .catch((err) => {
      res.status(404).send("No Post Found");
    });
};

exports.getPostByCategory = (req, res) => {
  Posts.find({ category: req.params.category_name.trim() })
    .populate("category")
    .then((posts) => {
      res.json(posts);
    })
    .catch((err) => {
      res.status(404).send("No post Found");
    });
};

exports.createPost = (req, res) => {
  if (req.body.media == "empty") {
    req.body.media = [];
  }
  if (req.body.media_tag == "empty") {
    req.body.media_tag = [];
  }
  if (req.body.hashtags == "empty") {
    req.body.hashtags = [];
  }

  const date = new Date();
  date.setHours(date.getHours() + 5);
  date.setMinutes(date.getMinutes() + 30);

  const post = new Posts({
    user_id: req.user.user_id,
    post_title: req.body.post_title,
    author_name: req.body.author_name,
    post_content: req.body.post_content,
    forum_image_content: req.body.forum_image_content,
    category: req.body.category,
    hashtags: req.body.hashtags,
    media: req.body.media,
    media_tag: req.body.media_tag,
    post_type: req.body.post_type,
    published_on: date,
  });

  post
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "Post created" });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "error creating the post" });
    });
};

exports.updatePost = (req, res) => {
  if (req.body.del_media_array == "empty") {
    req.body.del_media_array = [];
  }
  if (req.body.media == "empty") {
    req.body.media = [];
  }
  if (req.body.media_tag == "empty") {
    req.body.media_tag = [];
  }
  if (req.body.hashtags == "empty") {
    req.body.hashtags = [];
  }
  const updatedPost = {
    post_title: req.body.post_title,
    post_content: req.body.post_content,
    category: req.body.category,
    hashtags: req.body.hashtags,
    media: req.body.media,
    media_tag: req.body.media_tag,
  };
  req.body.del_media_array.forEach((file) => {
    fs.unlinkSync(file, (err) => {
      if (err) throw err;
      console.log("deleted");
    });
  });
  Posts.updateOne({ _id: ObjectId(req.params.post_id) }, updatedPost)
    .then(() => res.status(200).json({ success: true, msg: "post updated" }))
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't update post" })
    );
};

//Delete post
exports.deletePost = (req, res) => {
  Posts.findOne({ _id: ObjectId(req.params.post_id) })
    .then((post) => {
      post.media.forEach((file) => {
        console.log(file);
        fs.unlinkSync(file, (err) => {
          if (err) throw err;
          console.log("deleted");
        });
      });

      //Delete Comments of Post
      Comments.deleteMany({ post_id: req.params.post_id })
        .then(() => {
          //Delete Replies of Post
          ReplyComments.deleteMany({ post_id: req.params.post_id })
            .then(() => {
              //Delete Reports of that post
              Reports.deleteMany({ post_id: req.params.post_id })
                .then(() => {
                  //Delete id of that post from user bookmarked array
                  Users.updateMany(
                    { _id: { $in: post.bookmarks } },
                    { $pull: { bookmarks: req.params.post_id } }
                  )
                    .then(() => {
                      //Delete notifications of that post
                      Notifications.deleteMany({ post_id: req.params.post_id })
                        .then(() => {
                          res
                            .status(200)
                            .json({ success: true, msg: "Post deleted" });
                        })
                        .catch(() => {
                          res.status(400).json({
                            success: false,
                            msg: "error deleting notifications",
                          });
                        });
                    })
                    .catch((err) => {
                      res.status(400).json({
                        success: false,
                        msg: "error deleting boomarks",
                      });
                    });
                })
                .catch((err) => {
                  res.status(400).json({
                    success: false,
                    msg: "can't delete reports of posts",
                  });
                });
            })
            .catch(() => {
              res
                .status(400)
                .json({ success: false, msg: "can't delete replies of posts" });
            });
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "can't delete comments of posts" });
        });

      post.remove();
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "can't delete post" });
    });
};
