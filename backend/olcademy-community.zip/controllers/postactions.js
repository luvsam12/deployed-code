var connection = require("../config/mysql_db_con");
const Posts = require("../models/post");
const ObjectId = require("mongodb").ObjectID;
const Users = require("../models/user");
const Comments = require("../models/comment");
const ReplyComments = require("../models/commentreply");
const Reports = require("../models/report");

exports.increaseViews = (req, res) => {
  Posts.updateOne(
    { _id: ObjectId(req.params.post_id) },
    { $inc: { num_of_views: 1 } }
  )
    .then(() => {
      res.status(200).json({ success: true, msg: "Views Increased" });
    })
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't increase views" })
    );
};

//Route to increase share of post
exports.increaseShare = (req, res) => {
  Posts.updateOne(
    { _id: ObjectId(req.params.post_id) },
    { $inc: { num_of_shares: 1 } }
  )
    .then(() => {
      res.status(200).json({ success: true, msg: "Share Increased" });
    })
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't increase Share" })
    );
};

//Route to turn on notification
exports.postNotifications = (req, res) => {
  Posts.updateOne(
    { _id: ObjectId(req.params.post_id) },
    { $addToSet: { notifications: [req.user.user_id] } }
  )
    .then(() =>
      res.status(200).json({ success: true, msg: "Notification turned on" })
    )
    .catch((err) =>
      res
        .status(400)
        .json({ success: false, msg: "Can't turn on Notifications." })
    );
};

//Route to turn off notification
exports.deleteNotifications = (req, res) => {
  Posts.updateOne(
    { _id: ObjectId(req.params.post_id) },
    { $pull: { notifications: req.user.user_id } }
  )
    .then(() =>
      res.status(200).json({ success: true, msg: "Notification turned Off" })
    )
    .catch((err) =>
      res
        .status(400)
        .json({ success: false, msg: "Can't turn off Notifications." })
    );
};

// To get all Kudos of the particular Post
exports.getPostLike = (req, res) => {
  Posts.find({ _id: ObjectId(req.params.post_id) })
    .then((post) => {
      Users.find({ _id: { $in: post[0].likes } })
        .then((result) => {
          res.json(result);
        })
        .catch((err) => {
          res.status(400).json({ success: false, msg: "no data found" });
        });
    })

    .catch((err) => {
      res.status(404).send("No data found");
    });
};

// To get all users who like the comment
exports.getCommentLike = (req, res) => {
  Comments.find({ _id: ObjectId(req.params.comment_id) })
    .then((comment) => {
      Users.find({ _id: { $in: comment[0].likes } })
        .then((result) => {
          res.json(result);
        })
        .catch((err) => {
          res.status(400).json({ success: false, msg: "no data found" });
        });
    })

    .catch((err) => {
      res.status(404).send("No data found");
    });
};

// To get all users who like the reply comment
exports.getReplyLike = (req, res) => {
  ReplyComments.find({ _id: ObjectId(req.params.reply_comment_id) })
    .then((replycomment) => {
      Users.find({ _id: { $in: replycomment[0].likes } })
        .then((result) => {
          res.json(result);
        })
        .catch((err) => {
          res.status(400).json({ success: false, msg: "no data found" });
        });
    })

    .catch((err) => {
      res.status(404).send("No data found");
    });
};

//To Post Likes on particular Post, comment, reply comment
exports.postLike = (req, res) => {
  const type = req.body.like_type;
  if (type == "Post") {
    Posts.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $addToSet: { likes: [req.user.user_id] } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like Saved in Post" })
      )
      .catch((err) =>
        res.status(400).json({ success: false, msg: "can't save Like in Post" })
      );
  } else if (type == "Comment") {
    Comments.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $addToSet: { likes: [req.user.user_id] } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like Saved in Comment" })
      )
      .catch((err) =>
        res
          .status(400)
          .json({ success: false, msg: "can't save Like in Comment" })
      );
  } else if (type == "Reply") {
    ReplyComments.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $addToSet: { likes: [req.user.user_id] } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like Saved in Replies" })
      )
      .catch((err) =>
        res
          .status(400)
          .json({ success: false, msg: "can't save Like in Replies" })
      );
  }
};

// To delete Likes of Particular Post, Comment, Reply Comment
exports.deleteLikes = (req, res) => {
  const type = req.body.like_type;
  if (type == "Post") {
    Posts.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $pull: { likes: req.user.user_id } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like deleted in Post" })
      )
      .catch((err) =>
        res
          .status(400)
          .json({ success: false, msg: "can't delete Likes in Post " })
      );
  } else if (type == "Comment") {
    Comments.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $pull: { likes: req.user.user_id } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like deleted in Comment" })
      )
      .catch((err) =>
        res
          .status(400)
          .json({ success: false, msg: "can't delete Likes in Comment " })
      );
  } else if (type == "Reply") {
    ReplyComments.updateOne(
      { _id: ObjectId(req.body.like_id) },
      { $pull: { likes: req.user.user_id } }
    )
      .then(() =>
        res.status(200).json({ success: true, msg: "Like deleted in Reply" })
      )
      .catch((err) =>
        res
          .status(400)
          .json({ success: false, msg: "can't delete Likes in Reply " })
      );
  }
};

// To post Boomark for the particular Post
exports.postBookmarks = (req, res) => {
  Users.updateOne(
    { _id: req.user.user_id },
    { $addToSet: { bookmarks: [req.params.post_id] } }
  )
    .then(() =>
      Posts.updateOne(
        { _id: ObjectId(req.params.post_id) },
        { $addToSet: { bookmarks: [req.user.user_id] } }
      )
        .then(() =>
          res.status(200).json({ success: true, msg: "Bookmark Saved" })
        )
        .catch((err) =>
          res.status(400).json({ success: false, msg: "can't Save User" })
        )
    )
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't Save User" })
    );
};

//To delete bookmark for particular Post
exports.deleteBookmarks = (req, res) => {
  Users.updateOne(
    { _id: req.user.user_id },
    { $pull: { bookmarks: req.params.post_id } }
  )
    .then(() =>
      Posts.updateOne(
        { _id: ObjectId(req.params.post_id) },
        { $pull: { bookmarks: req.user._id } }
      )
        .then(() =>
          res.status(200).json({ success: true, msg: "Bookmark deleted" })
        )
        .catch((err) =>
          res.status(400).json({ success: false, msg: "can't delete User" })
        )
    )
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't delete User" })
    );
};

//Report any post
//Also increase value of report acc. to report type
exports.postReport = (req, res) => {
  const type = req.body.report_type;

  //saving the report in report table
  const report = new Reports({
    user_id: req.user.user_id,
    post_id: req.body.post_id,
    report_type: req.body.report_type,
    additional_comment: req.body.additional_comment,
  });

  report
    .save()
    .then(() => {
      // increasing report type in post
      if (type == "Spam") {
        Posts.updateOne(
          { _id: ObjectId(req.body.post_id) },
          { $inc: { spam: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Inappropriate Content") {
        Posts.updateOne(
          { _id: ObjectId(req.body.post_id) },
          { $inc: { inappropriate_content: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Harassment") {
        Posts.updateOne(
          { _id: ObjectId(req.body.post_id) },
          { $inc: { harassment: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Copyright Issue") {
        Posts.updateOne(
          { _id: ObjectId(req.body.post_id) },
          { $inc: { copyright_issue: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else {
        Posts.updateOne(
          { _id: ObjectId(req.body.post_id) },
          { $inc: { other: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      }
      //check if report type reach the particular limit
      Posts.findOne({ _id: ObjectId(req.body.post_id) })
        .then((post) => {
          if (
            post.spam >= 4 ||
            post.inappropriate_content >= 4 ||
            post.harassment >= 4 ||
            post.copyright_issue >= 4 ||
            post.other >= 4
          ) {
            Posts.updateOne({ _id: ObjectId(req.body.post_id) }, { show: 0 })
              .then(() => {
                res
                  .status(200)
                  .json({ success: true, msg: "Limit reached show = 0" });
              })
              .catch(() => {
                res
                  .status(400)
                  .json({ success: false, msg: "error in updating show = 0" });
              });
          } else {
            res
              .status(200)
              .json({ success: true, msg: "limit not reached so show = 1" });
          }
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "error in finding post" });
        });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error Reporting post" });
    });
};

//Report any comment
exports.commentreport = (req, res) => {
  const type = req.body.report_type;

  //saving the report in report table
  const report = new Reports({
    post_id: req.body.post_id,
    user_id: req.user.user_id,
    comment_id: req.body.comment_id,
    report_type: req.body.report_type,
    additional_comment: req.body.additional_comment,
  });

  report
    .save()
    .then(() => {
      // increasing report type in post
      if (type == "Spam") {
        Comments.updateOne(
          { _id: ObjectId(req.body.comment_id) },
          { $inc: { spam: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Inappropriate Content") {
        Comments.updateOne(
          { _id: ObjectId(req.body.comment_id) },
          { $inc: { inappropriate_content: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Harassment") {
        Comments.updateOne(
          { _id: ObjectId(req.body.comment_id) },
          { $inc: { harassment: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Copyright Issue") {
        Comments.updateOne(
          { _id: ObjectId(req.body.comment_id) },
          { $inc: { copyright_issue: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else {
        Comments.updateOne(
          { _id: ObjectId(req.body.comment_id) },
          { $inc: { other: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      }
      //check if report type reach the particular limit
      Comments.findOne({ _id: ObjectId(req.body.comment_id) })
        .then((comment) => {
          if (
            comment.spam >= 4 ||
            comment.inappropriate_content >= 4 ||
            comment.harassment >= 4 ||
            comment.copyright_issue >= 4 ||
            comment.other >= 4
          ) {
            Comments.updateOne(
              { _id: ObjectId(req.body.comment_id) },
              { show: 0 }
            )
              .then(() => {
                res
                  .status(200)
                  .json({ success: true, msg: "Limit reached show = 0" });
              })
              .catch(() => {
                res
                  .status(400)
                  .json({ success: false, msg: "error in updating show = 0" });
              });
          } else {
            res
              .status(200)
              .json({ success: true, msg: "limit not reached so show = 1" });
          }
        })
        .catch((err) => {
          res
            .status(400)
            .json({ success: false, msg: "error in finding comment" });
        });
    })

    .catch((err) => {
      res.status(400).json({ success: false, msg: "error Reporting Comment" });
    });
};

//Report for comment reply
exports.replycommentreport = (req, res) => {
  const type = req.body.report_type;

  //saving the report in report table
  const report = new Reports({
    post_id: req.body.post_id,
    user_id: req.user.user_id,
    reply_comment_id: req.body.reply_comment_id,
    report_type: req.body.report_type,
    additional_comment: req.body.additional_comment,
  });

  report
    .save()
    .then(() => {
      // increasing report type in post
      if (type == "Spam") {
        ReplyComments.updateOne(
          { _id: ObjectId(req.body.reply_comment_id) },
          { $inc: { spam: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Inappropriate Content") {
        ReplyComments.updateOne(
          { _id: ObjectId(req.body.reply_comment_id) },
          { $inc: { inappropriate_content: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Harassment") {
        ReplyComments.updateOne(
          { _id: ObjectId(req.body.reply_comment_id) },
          { $inc: { harassment: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else if (type == "Copyright Issue") {
        ReplyComments.updateOne(
          { _id: ObjectId(req.body.reply_comment_id) },
          { $inc: { copyright_issue: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      } else {
        ReplyComments.updateOne(
          { _id: ObjectId(req.body.reply_comment_id) },
          { $inc: { other: 1, reports: 1 } }
        )
          .then(() => {})
          .catch(() => {
            res
              .status(400)
              .json({ success: false, msg: "error increasing report value" });
          });
      }
      //check if report type reach the particular limit
      ReplyComments.findOne({ _id: ObjectId(req.body.reply_comment_id) })
        .then((reply) => {
          if (
            reply.spam >= 4 ||
            reply.inappropriate_content >= 4 ||
            reply.harassment >= 4 ||
            reply.copyright_issue >= 4 ||
            reply.other >= 4
          ) {
            ReplyComments.updateOne(
              { _id: ObjectId(req.body.reply_comment_id) },
              { show: 0 }
            )
              .then(() => {
                res
                  .status(200)
                  .json({ success: true, msg: "Limit reached show = 0" });
              })
              .catch(() => {
                res
                  .status(400)
                  .json({ success: false, msg: "error in updating show = 0" });
              });
          } else {
            res
              .status(200)
              .json({ success: true, msg: "limit not reached so show = 1" });
          }
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "error in finding reply of comment" });
        });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error Reporting reply comment" });
    });
};

exports.postComment = (req, res) => {
  let user_type = "";
  Users.findOne({ _id: req.user.user_id }).then((user) => {
    if (user.is_admin === 1) {
      user_type = "Admin";
    } else if (user.is_instructor === 1) {
      user_type = "Instructor";
    } else {
      user_type = "Student";
    }
    const comment = new Comments({
      post_id: req.params.post_id,
      user_id: req.user.user_id,
      full_name: req.body.author_name,
      user_type: user_type,
      about_user: "",
      comment: req.body.comment,
    });
    comment
      .save()
      .then(() => {
        Posts.updateOne(
          { _id: ObjectId(req.params.post_id) },
          { $inc: { comments: 1 } }
        ).then(() => {});
        res.status(200).json({ success: true, msg: "comment posted" });
      })
      .catch((err) => {
        console.log(err);
        res.status(400).json({ success: false, msg: "error posting comment" });
      });
  });
};

exports.postReplyComment = (req, res) => {
  let user_type = "";
  Users.findOne({ _id: req.user.user_id }).then((user) => {
    if (user.is_admin === 1) {
      user_type = "Admin";
    } else if (user.is_instructor === 1) {
      user_type = "Instructor";
    } else {
      user_type = "Student";
    }
    const replyComment = new ReplyComments({
      user_id: req.user.user_id,
      full_name: req.body.author_name,
      user_type: user_type,
      about_user: "",
      parent_comment_id: req.body.parent_comment_id,
      comment: req.body.comment,
      post_id: req.params.post_id,
    });
    replyComment
      .save()
      .then(() => {
        Comments.updateOne(
          { _id: ObjectId(req.body.parent_comment_id) },
          { $inc: { num_of_replies: 1 } }
        ).then(() => {});
        Posts.updateOne(
          { _id: ObjectId(req.params.post_id) },
          { $inc: { comments: 1 } }
        ).then(() => {});
        res.status(200).json({ success: true, msg: "Reply comment posted" });
      })
      .catch((err) => {
        console.log(err);
        res
          .status(400)
          .json({ success: false, msg: "Error posting reply comment" });
      });
  });
};

exports.deleteComment = (req, res) => {
  Comments.deleteOne({ _id: ObjectId(req.params.comment_id) })
    .then(() => {
      // console.log("deleted");
      ReplyComments.deleteMany({
        parent_comment_id: ObjectId(req.params.comment_id),
      }).then(() => {
        res
          .status(200)
          .json({ success: true, msg: "Comments deleted successfully" });
        // console.log("Replies deleted");
      });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error deleting comments" });
    });
};

exports.deleteReplyComment = (req, res) => {
  ReplyComments.deleteOne({ _id: ObjectId(req.params.comment_id) })
    .then(() => {
      res
        .status(200)
        .json({ success: true, msg: "Reply deleted successfully" });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error deleting comments" });
    });
};

exports.getParentComments = (req, res) => {
  Comments.find({ post_id: ObjectId(req.params.post_id), show: 1 })
    .then((comments) => {
      res.status(200).json({ success: true, comments: comments });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error fetching comments" });
    });
};

exports.getReplyComments = (req, res) => {
  ReplyComments.find({
    parent_comment_id: ObjectId(req.params.parent_comment_id),
    show: 1,
  })
    .then((replyComments) => {
      res.status(200).json({ success: true, replyComments: replyComments });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error fetching replies" });
    });
};
