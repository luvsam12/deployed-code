var connection = require("../config/mysql_db_con");
const jwt = require("jsonwebtoken");
const User = require("../models/user");
const Posts = require("../models/post");
const Interests = require("../models/category");
const Skills = require("../models/skill");
const Experiences = require("../models/experience");
const Educations = require("../models/education");
const Researchs = require("../models/research");
const Social = require("../models/socialprofile");
const Certificates = require("../models/certificate");
const ObjectId = require("mongodb").ObjectID;
const Notifications = require("../models/notification");
const Emailverification = require("../models/emailverification");
const { Mongoose } = require("mongoose");
const { sendEmail } = require("../mailes/mail");
const uuid = require("uuid");

exports.abc = (req, res) => {
  // console.log(uuid.v4());
};

exports.registerUser = (req, res) => {
  req.body.user_email_id = req.body.user_email_id.toLowerCase();
  const user = new User(req.body);
  const verifytoken = uuid.v4();

  user
    .save()
    .then(() => {
      sendEmail(user.user_email_id, verifytoken, "emailVerification");

      User.find({ user_email_id: user.user_email_id })
        .then((id) => {
          const emailverify = new Emailverification({
            token: verifytoken,
            user_id: id[0]._id,
          });

          emailverify
            .save()
            .then(() => {
              res
                .status(200)
                .json({ success: true, msg: "New User and email sent" });
            })
            .catch((err) => {
              console.log(err);
              res.status(400).json({ success: false, msg: "Token not save" });
            });
        })
        .catch(() => {
          res.status(400).json({ success: false, msg: "can't find user" });
        });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "No user registred" });
    });
};

// User Login
exports.loginUser = (req, res) => {
  var email = req.body.user_email_id.toLowerCase();
  User.findOne({ user_email_id: email }, (err, user) => {
    if (!user)
      return res.json({
        loginSuccess: false,
        message: "Auth failed, email not found",
      });
    user.comparePassword(req.body.password, (err, isMatch) => {
      if (!isMatch)
        return res.json({ loginSuccess: false, message: "Wrong password" });
      user.generateToken((err, user) => {
        if (err) return res.status(400).send(err);
        authdata = {
          user_id: user._id,
          full_name: user.full_name,
        };
        const token = user.token;
        res.cookie("w_auth", user.token).status(200).json({
          loginSuccess: true,
          authdata,
          token,
        });
      });
    });
  });
};

// User Logout
exports.logoutUser = (req, res) => {
  User.findOneAndUpdate(
    { _id: req.user.user_id },
    { token: "" },
    (err, doc) => {
      if (err) return res.json({ success: false, err });
      return res.status(200).send({
        success: true,
      });
    }
  );
};

exports.verifyEmail = (req, res) => {
  console.log(req.params.token);
  Emailverification.findOne({ token: req.params.token })
    .then((value) => {
      User.updateOne({ _id: value.user_id }, { verified: "True" })
        .then(() => {
          Emailverification.deleteOne({ _id: value._id })
            .then(() => {
              res.redirect("https://testing-olcademy-community.herokuapp.com/login");
            })
            .catch((err) => {
              console.log(err);
              res
                .status(400)
                .json({ success: false, msg: "can't delete document" });
            });
        })
        .catch(() => {
          res.status(400).json({ success: false, msg: "can't write true" });
        });
    })
    .catch((err) => {
      res.redirect("register");
    });
};

//verify whether to show popup or not
//Access @Private
exports.postUserDocument = (req, res) => {
  const userId = req.user.user_id;
  User.findOne({ _id: userId }).then((user) => {
    // if (!user) {
    //   res.json({ msg: "user not found" });
    // } else {
    if (user.login_count >= 0) {
      if (user.login_count < 3 && user.interest.length === 0) {
        User.updateOne({ _id: userId }, { $inc: { login_count: 1 } })
          .then(() => res.json({ showPopup: true }))
          .catch(() => console.log("Cant Update"));
      } else {
        res.json({ showPopup: false });
      }
    } else {
      res.json({ showPopup: false });
    }
    // }
  });
};

//Get User Interest
//Access @Private
exports.getUserInterest = (req, res) => {
  User.find({ _id: req.user.user_id })
    .then((user) => {
      console.log(user);
      res.status(200).send({
        success: true,
        msg: user[0].interest,
      });
    })
    .catch((err) => {
      return res.status(400).json({
        error: "NO interest Found",
      });
    });
};

//Save User Interest
//Access @Private
exports.postUserInterest = (req, res) => {
  // console.log(req.body.interest);
  User.updateOne(
    { _id: req.user.user_id },
    { interest: req.body.interest, $unset: { login_count: "" } }
  )
    .then(() =>
      Interests.updateMany(
        { _id: { $in: req.body.interest } },
        { $inc: { num_of_followers: 1 } }
      )
        .then(() => {
          res
            .status(200)
            .json({ success: true, msg: "interest increased and saved" });
        })
        .catch((err) => {
          res
            .status(400)
            .json({ success: false, msg: "can't increase interest" });
        })
    )
    .catch((err) => res.send({ success: false }));
};

//Save user single Interest
exports.postSingleInterest = (req, res) => {
  User.updateOne(
    { _id: req.user.user_id },
    { $addToSet: { interest: [req.params.interest_id] } }
  ).then(() => {
    Interests.updateOne(
      { _id: ObjectId(req.params.interest_id) },
      { $inc: { num_of_followers: 1 } }
    )
      .then(() => {
        res
          .status(200)
          .json({ success: true, msg: "interest increased and saved" });
      })
      .catch(() => {
        res
          .status(400)
          .json({ success: false, msg: "can't increase interest" });
      });
  });
};

//Delete User Interest
exports.deleteSingleInterest = (req, res) => {
  User.updateOne(
    { _id: req.user.user_id },
    { $pull: { interest: req.params.interest_id } }
  ).then(() => {
    Interests.updateOne(
      { _id: ObjectId(req.params.interest_id) },
      { $inc: { num_of_followers: -1 } }
    )
      .then(() => {
        res
          .status(200)
          .json({ success: true, msg: "interest decreased and deleted" });
      })
      .catch(() => {
        res
          .status(400)
          .json({ success: false, msg: "can't decrease interest" });
      });
  });
};

//Get Profile Image of Users
exports.getProfileImage = (req, res) => {
  User.findOne({ _id: req.params.user_id }, { profile_image_path: 1 })
    .then((result) => {
      res.status(200).json({ success: true, data: result });
    })
    .catch(() => {
      res
        .status(400)
        .json({ success: false, msg: "error occured while fetching image" });
    });
};

//Follow User
exports.postFollow = (req, res) => {
  User.updateOne(
    { _id: req.user.user_id },
    { $addToSet: { following: [req.params.other_user_id] } }
  )
    .then(() => {
      User.updateOne(
        { _id: req.params.other_user_id },
        { $addToSet: { followers: [req.user.user_id] } }
      )
        .then(() => {
          res.status(200).json({ success: true, msg: "User followed" });
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "Can't save follow User" });
        });
    })
    .catch(() => {
      res.status(400).json({ success: false, msg: "Can't follow User" });
    });
};

//Unfollow User
exports.deleteFollow = (req, res) => {
  User.updateOne(
    { _id: req.user.user_id },
    { $pull: { following: req.params.other_user_id } }
  )
    .then(() => {
      User.updateOne(
        { _id: ObjectId(req.params.other_user_id) },
        { $pull: { followers: req.user.user_id } }
      )
        .then(() => {
          res.status(200).json({ success: true, msg: "User unfollowed" });
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "Can't delete follow User" });
        });
    })
    .catch(() => {
      res.status(400).json({ success: false, msg: "Can't unfollow User" });
    });
};

//Get all post done by user

exports.getAllPost = (req, res) => {
  // console.log(req.user.user_id);
  Posts.find({ user_id: req.user.user_id })
    .populate("category")
    .then((post) => {
      res.json(post);
    })
    .catch(() => {
      res.status(400).json({ success: false, msg: "Can't find user" });
    });
};

//To get total Kudos of the user
exports.getKudos = (req, res) => {
  User.find({ _id: req.user.user_id })
    .then((user) => {
      res.json(user[0].kudos);
    })
    .catch((err) => {
      res.status(404).send("No data found");
    });
};

//To get all the bookmarks of the user
exports.getBookmarks = (req, res) => {
  User.find({ _id: req.user.user_id })
    .then((user) => {
      Posts.find({ _id: { $in: user[0].bookmarks } })
        .populate("category")
        .then((result) => {
          res.json(result);
        })
        .catch((err) => {
          res.status(400).json({ success: false, msg: "no data found" });
        });
    })
    .catch((err) => {
      res.status(404).send("No data found");
    });
};

//Send connection request
exports.postconnectionrequest = (req, res) => {
  // console.log(req.body);
  User.updateOne(
    { _id: req.body.from_user },
    { $addToSet: { requested: [req.body.to_user] } }
  )
    .then(() => {
      User.updateOne(
        { _id: req.body.to_user },
        { $addToSet: { pending: req.body.from_user } }
      )
        .then(() => {
          res
            .status(200)
            .json({ success: true, msg: "User succesfully requested" });
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "can't save in Pending array" });
        });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "can't save in requested array" });
    });
};

//Accept connection request
exports.postconnection = (req, res) => {
  User.updateOne(
    { _id: req.body.from_user },
    {
      $pull: { requested: req.body.to_user },
      $addToSet: { connections: [req.body.to_user] },
    }
  )
    .then(() => {
      User.updateOne(
        { _id: req.body.to_user },
        {
          $pull: { pending: req.body.from_user },
          $addToSet: { connections: [req.body.from_user] },
        }
      )
        .then(() => {
          res
            .status(200)
            .json({ success: true, msg: "User succesfully connected" });
        })
        .catch(() => {
          res.status(400).json({
            success: false,
            msg: "can't save in to user connection array",
          });
        });
    })
    .catch(() => {
      res.status(400).json({
        success: false,
        msg: "can't save in from user connection array",
      });
    });
};

//Reject Connection Request
exports.deleteconnectionrequest = (req, res) => {
  User.updateOne(
    { _id: req.body.from_user },
    { $pull: { requested: req.body.to_user } }
  )
    .then(() => {
      User.updateOne(
        { _id: req.body.to_user },
        { $pull: { pending: req.body.from_user } }
      )
        .then(() => {
          res
            .status(200)
            .json({ success: true, msg: "User succesfully rejected" });
        })
        .catch(() => {
          res
            .status(400)
            .json({ success: false, msg: "can't reject from pending array" });
        });
    })
    .catch(() => {
      res
        .status(400)
        .json({ success: false, msg: "can't reject from requested array" });
    });
};

//Disconnect user
exports.deleteconnection = (req, res) => {
  User.updateOne(
    { _id: req.body.from_user },
    { $pull: { connections: req.body.to_user } }
  )
    .then(() => {
      User.updateOne(
        { _id: req.body.to_user },
        { $pull: { connections: req.body.from_user } }
      )
        .then(() => {
          res
            .status(200)
            .json({ success: true, msg: "User succesfully disconnected" });
        })
        .catch(() => {
          res.status(400).json({
            success: false,
            msg: "can't disconnect to user connections array",
          });
        });
    })
    .catch(() => {
      res
        .status(400)
        .json({ success: false, msg: "can't disconnect from user array" });
    });
};

//to get notification of a user
exports.getNotifications = (req, res) => {
  Notifications.find({ user_id: req.user.user_id })
    .then((notifications) => {
      res.status(200).json({ success: true, data: notifications });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "no data found" });
    });
};

exports.saveNotification = (req, res) => {
  const notification = new Notifications({
    user_id: req.user.user_id,
    post_id: req.body.post_id,
    sender_id: req.body.sender_id,
    notification_message: "Test Notification 4",
  });
  notification
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "notification saved" });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "no data found" });
    });
};

//Route for fetching user data
exports.getUserPersonalDetails = (req, res) => {
  User.findOne({ _id: req.user.user_id }, { password: 0 })
    .then((user) => {
      res.status(200).json({ success: true, userData: user });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "no data found" });
    });
};

//Route for updating user personal details fullname and about user
exports.updateUserPersonalDetailsFirst = (req, res) => {
  const updatedUser = {
    full_name: req.body.full_name,
    about_user: req.body.about_user,
  };
  User.updateOne({ _id: ObjectId(req.user.user_id) }, updatedUser)
    .then(() =>
      res.status(200).json({ success: true, msg: "User Details updated" })
    )
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't update User Details" })
    );
};

//Route for updating user other details
exports.updateUserPersonalDetailsSecond = (req, res) => {
  const updatedUser = {
    date_of_birth: req.body.date_of_birth,
    user_country: req.body.user_country,
    user_address: req.body.user_address,
    user_bio: req.body.user_bio,
  };
  User.updateOne({ _id: ObjectId(req.user.user_id) }, updatedUser)
    .then(() =>
      res.status(200).json({ success: true, msg: "User Details updated" })
    )
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't update User Details" })
    );
};

//Route for changing profile image
exports.changeProfileImage = (req, res) => {
  var filepath = "public/upload/" + req.files[0].filename;
  const updatedUser = {
    profile_image_path: filepath,
  };
  console.log(req.files);
  User.updateOne({ _id: req.user.user_id }, updatedUser)
    .then(() =>
      res.status(200).json({ success: true, msg: "User Profile updated" })
    )
    .catch((err) =>
      res.status(400).json({ success: false, msg: "can't update User Profile" })
    );
};

//Route for getting skills of user
exports.getSkills = (req, res) => {
  var userId = req.user.user_id;
  Skills.find({ user_id: userId })
    .then((skills) => {
      res.status(200).json({ success: true, data: skills });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for posting skills of user
exports.postSkills = (req, res) => {
  var userId = req.user.user_id;
  const newSkill = new Skills({
    user_skill: req.body.user_skill,
    user_skill_rating: req.body.user_skill_rating,
    user_id: userId,
  });
  newSkill
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "Skill created" });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "error creating the skill" });
    });
};

//Route for updating skills of user
exports.updateSkills = (req, res) => {
  var userId = req.user.user_id;
  const updatedSkill = new Skills({
    _id: req.body.skill_id,
    user_skill: req.body.user_skill,
    user_skill_rating: req.body.user_skill_rating,
    user_id: userId,
  });
  Skills.updateOne({ _id: req.body.skill_id }, updatedSkill)
    .then(() => {
      res.status(200).json({ success: true, msg: "Skill updated" });
    })
    .catch((err) => {
      console.log(err);
      res.status(400).json({ success: false, msg: "error updating the skill" });
    });
};

//Route for deleting skills of user
exports.deleteSkills = (req, res) => {
  Skills.deleteOne({ _id: req.params.skill_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "Skill deleted" });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: "error deleting the skill" });
    });
};

//Route for getting experience of user
exports.getExperience = (req, res) => {
  var userId = req.user.user_id;
  Experiences.find({ user_id: userId })
    .then((experiences) => {
      res.status(200).json({ success: true, data: experiences });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for posting experience of user
exports.postExperience = (req, res) => {
  var userId = req.user.user_id;
  const newExperience = new Experiences({
    company_name: req.body.company_name,
    designation_title: req.body.designation_title,
    job_start_date: req.body.job_start_date,
    job_end_date: req.body.job_end_date,
    user_id: userId,
  });
  newExperience
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "Experience created" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error creating the experience" });
    });
};

//Route for Updating user experience
exports.updateExperience = (req, res) => {
  var userId = req.user.user_id;
  const updatedExperience = new Experiences({
    company_name: req.body.company_name,
    designation_title: req.body.designation_title,
    job_start_date: req.body.job_start_date,
    job_end_date: req.body.job_end_date,
    user_id: userId,
    _id: req.body.experience_id,
  });
  Experiences.updateOne({ _id: req.body.experience_id }, updatedExperience)
    .then(() => {
      res.status(200).json({ success: true, msg: "Experience Updated" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error updating the experience" });
    });
};

//Route for deleting experience of user
exports.deleteExperience = (req, res) => {
  Experiences.deleteOne({ _id: req.params.experience_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "Experience deleted" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error deleting the experience" });
    });
};

//Route for getting Education of user
exports.getEducation = (req, res) => {
  var userId = req.user.user_id;
  Educations.find({ user_id: userId })
    .then((educations) => {
      res.status(200).json({ success: true, data: educations });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for creating education of user
exports.postEducation = (req, res) => {
  var userId = req.user.user_id;
  const newEducation = new Educations({
    institution_name: req.body.institution_name,
    degree_title: req.body.degree_title,
    degree_start_date: req.body.degree_start_date,
    degree_end_date: req.body.degree_end_date,
    degree_grade: req.body.degree_grade,
    user_id: userId,
  });
  newEducation
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "Education created" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error creating the education" });
    });
};

//Route for updating education of user
exports.updateEducation = (req, res) => {
  var userId = req.user.user_id;
  const updatedEducation = new Educations({
    institution_name: req.body.institution_name,
    degree_title: req.body.degree_title,
    degree_start_date: req.body.degree_start_date,
    degree_end_date: req.body.degree_end_date,
    degree_grade: req.body.degree_grade,
    user_id: userId,
    _id: req.body.education_id,
  });
  Educations.updateOne({ _id: req.body.education_id }, updatedEducation)
    .then(() => {
      res.status(200).json({ success: true, msg: "Education Updated" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error updating the education" });
    });
};

//Route for deleting education of user
exports.deleteEducation = (req, res) => {
  Educations.deleteOne({ _id: req.params.education_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "Education deleted" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error deleting the education" });
    });
};

//Route for getting Research of user
exports.getResearch = (req, res) => {
  var userId = req.user.user_id;
  Researchs.find({ user_id: userId })
    .then((research) => {
      res.status(200).json({ success: true, data: research });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for creating Research of user
exports.postResearch = (req, res) => {
  var userId = req.user.user_id;
  const newResearch = new Researchs({
    research_topic: req.body.research_topic,
    publication_date: req.body.publication_date,
    user_id: userId,
  });
  newResearch
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "Research created" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error creating the Research" });
    });
};

//Route for updating Research of user
exports.updateResearch = (req, res) => {
  var userId = req.user.user_id;
  const updatedResearch = new Researchs({
    _id: req.body.research_id,
    research_topic: req.body.research_topic,
    publication_date: req.body.publication_date,
    user_id: userId,
  });
  Researchs.updateOne({ _id: req.body.research_id }, updatedResearch)
    .then(() => {
      res.status(200).json({ success: true, msg: "Research Updated" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error updating the Research" });
    });
};

//Route for deleting Research of user
exports.deleteResearch = (req, res) => {
  Researchs.deleteOne({ _id: req.params.research_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "Research deleted" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error deleting the Research" });
    });
};

//Route for getting Research of user
exports.getCertificate = (req, res) => {
  var userId = req.user.user_id;
  Certificates.find({ user_id: userId })
    .then((certificate) => {
      res.status(200).json({ success: true, data: certificate });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for creating Research of user
exports.postCertificate = (req, res) => {
  var userId = req.user.user_id;
  const newCertificate = new Certificates({
    certifying_firm: req.body.certifying_firm,
    name_of_certification: req.body.name_of_certification,
    date_of_completion: req.body.date_of_completion,
    user_id: userId,
  });
  newCertificate
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "certificate created" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error creating the certificate" });
    });
};

//Route for updating Research of user
exports.updateCertificate = (req, res) => {
  var userId = req.user.user_id;
  const updatedCertificate = new Certificates({
    _id: req.body.certificate_id,
    certifying_firm: req.body.certifying_firm,
    name_of_certification: req.body.name_of_certification,
    date_of_completion: req.body.date_of_completion,
    user_id: userId,
  });
  Certificates.updateOne({ _id: req.body.certificate_id }, updatedCertificate)
    .then(() => {
      res.status(200).json({ success: true, msg: "certificate Updated" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error updating the certificate" });
    });
};

//Route for deleting Research of user
exports.deleteCertificate = (req, res) => {
  Certificates.deleteOne({ _id: req.params.certificate_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "certificate deleted" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error deleting the certificate" });
    });
};

//Route for getting Social Profile of user
exports.getSocial = (req, res) => {
  var userId = req.user.user_id;
  Social.find({ user_id: userId })
    .then((social) => {
      res.status(200).json({ success: true, data: social });
    })
    .catch((err) => {
      res.status(400).json({ success: false, msg: err });
    });
};

//Route for creating Social Profile of user
exports.postSocial = (req, res) => {
  var userId = req.user.user_id;
  const newSocial = new Social({
    website: req.body.website,
    username: req.body.username,
    link: req.body.link,
    user_id: userId,
  });
  newSocial
    .save()
    .then(() => {
      res.status(200).json({ success: true, msg: "social profile created" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error creating the social profile" });
    });
};

//Route for updating Social Profile of user
exports.updateSocial = (req, res) => {
  var userId = req.user.user_id;
  const updatedSocial = new Social({
    _id: req.body.social_id,
    website: req.body.website,
    username: req.body.username,
    link: req.body.link,
    user_id: userId,
  });
  Social.updateOne({ _id: req.body.social_id }, updatedSocial)
    .then(() => {
      res.status(200).json({ success: true, msg: "social profile Updated" });
    })
    .catch((err) => {
      console.log(err);
      res
        .status(400)
        .json({ success: false, msg: "error updating the social profile" });
    });
};

//Route for deleting Social Profile of user
exports.deleteSocial = (req, res) => {
  Social.deleteOne({ _id: req.params.social_id })
    .then(() => {
      res.status(200).json({ success: true, msg: "social profile deleted" });
    })
    .catch((err) => {
      res
        .status(400)
        .json({ success: false, msg: "error deleting the social profile" });
    });
};
